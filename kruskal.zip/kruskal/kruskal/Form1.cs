﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kruskal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<Tuple<string, double>> rangelist = new List<Tuple<string, double>>();
            List<Tuple<string, double>> list = new List<Tuple<string, double>>();
            int ii = 0;
            foreach(string s in textBox1.Text.Split("?"))
            {
                foreach(string s1 in s.Split(","))
                {
                    list.Add(Tuple.Create(ii.ToString(), double.Parse(s1)));
                }
                ii = ii + 1;
            }
            var order = list.OrderBy(e => e.Item2);
            double i = 1;
            foreach(var item in order)
            {
                rangelist.Add(Tuple.Create(item.Item1, i));
                i = i + 1;
            }
            var sumsquare = rangelist.GroupBy(e => e.Item1).Select(group => Math.Pow(
                    group.Sum(e => e.Item2), 2) / group.Count()).ToList();
            double hstatistics = ((12 / (Math.Pow(rangelist.Count(), 2)+rangelist.Count()) * sumsquare.Sum()) -
                (3 * rangelist.Count() + 3));
            MessageBox.Show("" + hstatistics);
        }
    }
}
